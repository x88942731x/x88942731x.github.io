using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        private string ffmpegPath = @"C:\ffmpeg\ffmpeg-8.0.1-essentials_build\bin\ffmpeg.exe";

        public Form1()
        {
            InitializeComponent();
            UpdateFormatMenu(); // 初期化
        }

        // ★ 拡張子に応じてメニューを切り替える
        private void UpdateFormatMenu()
        {
            cmbFormat.Items.Clear();

            string input = txtInput.Text.ToLower();
            string ext = Path.GetExtension(input);

            if (ext == ".m4a")
            {
                // m4a のときだけ mp4 を追加
                cmbFormat.Items.Add("mp4");
            }

            // 共通の音声形式
            cmbFormat.Items.Add("mp3");
            cmbFormat.Items.Add("wav");
            cmbFormat.Items.Add("ogg");

            cmbFormat.SelectedIndex = 0;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "メディアファイル|*.mp4;*.mov;*.avi;*.mkv;*.mp3;*.wav;*.ogg;*.aac;*.flac;*.m4a|すべてのファイル|*.*";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    txtInput.Text = ofd.FileName;
                    UpdateFormatMenu(); // ★ メニュー更新
                }
            }
        }

        private void btnOutput_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog fbd = new FolderBrowserDialog())
            {
                if (fbd.ShowDialog() == DialogResult.OK)
                {
                    txtOutput.Text = fbd.SelectedPath;
                }
            }
        }

        // ★ ドラッグされた時
        private void Form1_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                e.Effect = DragDropEffects.Copy;
            else
                e.Effect = DragDropEffects.None;
        }

        // ★ ドロップされた時（m4a もOK）
        private void Form1_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);

            if (files.Length > 0)
            {
                string file = files[0];
                string ext = Path.GetExtension(file).ToLower();

                string[] ok =
                {
                    ".mp4", ".mov", ".avi", ".mkv",
                    ".mp3", ".wav", ".ogg", ".aac", ".flac", ".m4a"
                };

                if (Array.Exists(ok, x => x == ext))
                {
                    txtInput.Text = file;
                    UpdateFormatMenu(); // ★ メニュー更新
                }
                else
                {
                    MessageBox.Show("対応している動画/音声ファイルをドロップしてください。");
                }
            }
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtInput.Text))
            {
                MessageBox.Show("入力ファイルを選択してください。");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtOutput.Text))
            {
                MessageBox.Show("保存先フォルダを選択してください。");
                return;
            }

            string input = txtInput.Text;
            string inputExt = Path.GetExtension(input).ToLower();
            string selected = cmbFormat.SelectedItem.ToString();
            string output = Path.Combine(
                txtOutput.Text,
                Path.GetFileNameWithoutExtension(input) + "." + selected
            );

            // ★ m4a → mp4 のときは無劣化コピー
            if (inputExt == ".m4a" && selected == "mp4")
            {
                RunFFmpeg($"-i \"{input}\" -c copy \"{output}\" -y");
                MessageBox.Show("m4a → mp4 変換が完了しました！");
                return;
            }

            // ★ 通常の音声変換
            RunFFmpeg($"-i \"{input}\" \"{output}\" -y");
            MessageBox.Show("変換が完了しました！");
        }

        // ★ FFmpeg 実行共通関数
        private void RunFFmpeg(string args)
        {
            ProcessStartInfo psi = new ProcessStartInfo
            {
                FileName = ffmpegPath,
                Arguments = args,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };

            using (Process process = Process.Start(psi))
            {
                string outputLog = process.StandardError.ReadToEnd();
                txtLog.Text = outputLog;
                process.WaitForExit();
            }
        }
    }
}
