﻿using System;
using System.Diagnostics;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace LauncherForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "25309")
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = @"C:\Program Files\Google\Chrome\Application\chrome.exe",
                    UseShellExecute = true
                });

                Close();
            }
            else
            {
                MessageBox.Show("パスワードが違います");
            }
        }
    }
}